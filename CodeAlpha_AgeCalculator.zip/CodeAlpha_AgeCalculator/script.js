// ==========================================
//  AGE CALCULATOR — CodeAlpha Internship
//  Author: Rao Danish
// ==========================================

const DAYS_OF_WEEK = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];

// Set today's date in footer on load
window.addEventListener('DOMContentLoaded', () => {
  const today = new Date();
  document.getElementById('todayDate').textContent =
    `${today.getDate()} ${MONTHS[today.getMonth()]} ${today.getFullYear()}`;
});

// ── Validation ─────────────────────────────────────────────
function isLeapYear(year) {
  return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}

function daysInMonth(month, year) {
  const days = [0,31,28,31,30,31,30,31,31,30,31,30,31];
  if (month === 2 && isLeapYear(year)) return 29;
  return days[month];
}

function validateInputs(day, month, year) {
  if (!day || !month || !year) return "Please fill in all three fields.";
  if (isNaN(day) || isNaN(month) || isNaN(year)) return "Please enter valid numbers.";
  if (month < 1 || month > 12) return "Month must be between 1 and 12.";
  if (year < 1900 || year > new Date().getFullYear()) return `Year must be between 1900 and ${new Date().getFullYear()}.`;
  if (day < 1 || day > daysInMonth(month, year)) return `Day must be between 1 and ${daysInMonth(month, year)} for that month.`;

  const inputDate = new Date(year, month - 1, day);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (inputDate > today) return "Date of birth cannot be in the future.";

  return null; // valid
}

// ── Core Age Calculation ────────────────────────────────────
function computeAge(day, month, year) {
  const today = new Date();
  const birthDate = new Date(year, month - 1, day);

  let years  = today.getFullYear() - birthDate.getFullYear();
  let months = today.getMonth()    - birthDate.getMonth();
  let days   = today.getDate()     - birthDate.getDate();

  if (days < 0) {
    months--;
    // Days in the previous month from today's perspective
    const prevMonth = new Date(today.getFullYear(), today.getMonth(), 0);
    days += prevMonth.getDate();
  }

  if (months < 0) {
    years--;
    months += 12;
  }

  // Total days lived
  const msPerDay = 1000 * 60 * 60 * 24;
  const totalDaysLived = Math.floor((today - birthDate) / msPerDay);

  // Next birthday
  let nextBirthday = new Date(today.getFullYear(), month - 1, day);
  if (nextBirthday <= today) {
    nextBirthday = new Date(today.getFullYear() + 1, month - 1, day);
  }
  const daysUntilBirthday = Math.ceil((nextBirthday - today) / msPerDay);

  return {
    years, months, days,
    totalDays: totalDaysLived,
    totalHours: (totalDaysLived * 24).toLocaleString(),
    nextBirthday: daysUntilBirthday === 0 ? "🎉 Today!" : `${daysUntilBirthday} days away`,
    birthDayName: DAYS_OF_WEEK[birthDate.getDay()],
    birthMonthName: MONTHS[month - 1]
  };
}

// ── Animate Number ──────────────────────────────────────────
function animateNumber(element, target) {
  const duration = 600;
  const start = performance.now();
  const from = 0;

  function step(now) {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    // Ease out cubic
    const ease = 1 - Math.pow(1 - progress, 3);
    const current = Math.round(from + (target - from) * ease);
    element.textContent = current;
    if (progress < 1) requestAnimationFrame(step);
  }

  requestAnimationFrame(step);
}

// ── Show Error ──────────────────────────────────────────────
function showError(msg) {
  const el = document.getElementById('errorMsg');
  el.textContent = msg;
}

function clearError() {
  document.getElementById('errorMsg').textContent = '';
}

// ── Main Calculate Function ─────────────────────────────────
function calculateAge() {
  clearError();

  const dayVal   = parseInt(document.getElementById('day').value.trim());
  const monthVal = parseInt(document.getElementById('month').value.trim());
  const yearVal  = parseInt(document.getElementById('year').value.trim());

  // Remove invalid class
  ['day','month','year'].forEach(id => {
    document.getElementById(id).classList.remove('invalid');
  });

  const error = validateInputs(dayVal, monthVal, yearVal);
  if (error) {
    showError(error);
    // Shake effect on empty fields
    ['day','month','year'].forEach(id => {
      const el = document.getElementById(id);
      if (!el.value) el.classList.add('invalid');
    });
    return;
  }

  const result = computeAge(dayVal, monthVal, yearVal);

  // ── Update result numbers with animation ──
  const numYears  = document.getElementById('numYears');
  const numMonths = document.getElementById('numMonths');
  const numDays   = document.getElementById('numDays');

  numYears.classList.add('num-pop');
  numMonths.classList.add('num-pop');
  numDays.classList.add('num-pop');

  setTimeout(() => numYears.classList.remove('num-pop'), 500);
  setTimeout(() => numMonths.classList.remove('num-pop'), 500);
  setTimeout(() => numDays.classList.remove('num-pop'), 500);

  animateNumber(numYears, result.years);
  animateNumber(numMonths, result.months);
  animateNumber(numDays, result.days);

  // ── Activate result cards ──
  document.getElementById('resYears').classList.add('active');
  document.getElementById('resMonths').classList.add('active');
  document.getElementById('resDays').classList.add('active');

  // ── Summary ──
  const summary = document.getElementById('resultSummary');
  summary.textContent =
    `You are ${result.years} year${result.years !== 1 ? 's' : ''}, ` +
    `${result.months} month${result.months !== 1 ? 's' : ''}, and ` +
    `${result.days} day${result.days !== 1 ? 's' : ''} old. ` +
    `You were born on a ${result.birthDayName}.`;
  summary.classList.add('show');

  // ── Extra Stats ──
  document.getElementById('totalDays').textContent   = result.totalDays.toLocaleString() + ' days';
  document.getElementById('totalHours').textContent  = result.totalHours + ' hours';
  document.getElementById('nextBirthday').textContent = result.nextBirthday;
  document.getElementById('birthDay').textContent    = `${result.birthDayName}, ${result.birthMonthName} ${dayVal}, ${yearVal}`;

  document.getElementById('extraStats').classList.add('show');
}

// ── Reset ───────────────────────────────────────────────────
function resetCalculator() {
  ['day','month','year'].forEach(id => {
    const el = document.getElementById(id);
    el.value = '';
    el.classList.remove('invalid');
  });

  clearError();

  document.getElementById('numYears').textContent  = '—';
  document.getElementById('numMonths').textContent = '—';
  document.getElementById('numDays').textContent   = '—';

  ['resYears','resMonths','resDays'].forEach(id => {
    document.getElementById(id).classList.remove('active');
  });

  document.getElementById('resultSummary').classList.remove('show');
  document.getElementById('resultSummary').textContent = '';
  document.getElementById('extraStats').classList.remove('show');
}

// ── Enter key support ───────────────────────────────────────
document.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') calculateAge();
});
